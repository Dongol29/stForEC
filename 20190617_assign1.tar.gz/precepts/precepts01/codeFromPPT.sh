#URL: http://www.ndsl.kaist.edu/ee209/precepts/01/src/
#Download source code and compile
wget www.ndsl.kaist.edu/ee209/precepts/01/src/circle.c
gcc209 circle.c –o circle
#Download the binary for base and guess
wget www.ndsl.kaist.edu/ee209/precepts/01/src/base
chmod u+x base
wget www.ndsl.kaist.edu/ee209/precepts/01/src/guess
chmod u+x guess
